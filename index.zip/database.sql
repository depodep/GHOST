-- GHOST Egg Incubator System - Database Schema
-- Run this SQL to set up the database

CREATE DATABASE IF NOT EXISTS ghost_incubator;
USE ghost_incubator;

-- ADMINS TABLE (separate from users)
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    profile_pic VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- USERS TABLE (separate from admins)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    profile_pic VARCHAR(255) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    status ENUM('active','inactive','suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- INCUBATORS TABLE
CREATE TABLE IF NOT EXISTS incubators (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    model VARCHAR(100) DEFAULT NULL,
    capacity INT DEFAULT 0,
    location VARCHAR(255) DEFAULT NULL,
    status ENUM('active','idle','maintenance','error') DEFAULT 'idle',
    owner_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- BATCHES TABLE
CREATE TABLE IF NOT EXISTS batches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    incubator_id INT NOT NULL,
    user_id INT NOT NULL,
    batch_name VARCHAR(100) NOT NULL,
    egg_type VARCHAR(100) DEFAULT 'Chicken',
    egg_count INT DEFAULT 0,
    start_date DATE NOT NULL,
    expected_hatch_date DATE NOT NULL,
    status ENUM('incubating','hatched','failed','cancelled') DEFAULT 'incubating',
    notes TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incubator_id) REFERENCES incubators(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- TEMPERATURE LOGS TABLE
CREATE TABLE IF NOT EXISTS temperature_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    incubator_id INT NOT NULL,
    temperature DECIMAL(5,2) NOT NULL,
    humidity DECIMAL(5,2) DEFAULT NULL,
    recorded_by ENUM('admin','user','auto') DEFAULT 'auto',
    recorded_id INT DEFAULT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incubator_id) REFERENCES incubators(id) ON DELETE CASCADE
);

-- SCHEDULES TABLE
CREATE TABLE IF NOT EXISTS schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    incubator_id INT NOT NULL,
    batch_id INT DEFAULT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT DEFAULT NULL,
    scheduled_date DATE NOT NULL,
    scheduled_time TIME NOT NULL,
    action_type ENUM('turning','temperature_check','humidity_check','candling','maintenance','hatch') DEFAULT 'turning',
    target_temp DECIMAL(5,2) DEFAULT NULL,
    target_humidity DECIMAL(5,2) DEFAULT NULL,
    status ENUM('pending','done','missed','cancelled') DEFAULT 'pending',
    created_by_role ENUM('admin','user') DEFAULT 'admin',
    created_by_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incubator_id) REFERENCES incubators(id) ON DELETE CASCADE,
    FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE SET NULL
);

-- TEMPERATURE SETTINGS TABLE
CREATE TABLE IF NOT EXISTS temperature_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    incubator_id INT NOT NULL UNIQUE,
    target_temp DECIMAL(5,2) DEFAULT 37.50,
    min_temp DECIMAL(5,2) DEFAULT 37.00,
    max_temp DECIMAL(5,2) DEFAULT 38.00,
    target_humidity DECIMAL(5,2) DEFAULT 55.00,
    min_humidity DECIMAL(5,2) DEFAULT 50.00,
    max_humidity DECIMAL(5,2) DEFAULT 60.00,
    turning_interval INT DEFAULT 8,
    updated_by_role ENUM('admin','user') DEFAULT 'admin',
    updated_by_id INT DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (incubator_id) REFERENCES incubators(id) ON DELETE CASCADE
);

-- HARDWARE STATE TABLE
-- Stores the latest ESP8266 heartbeat and live relay/sensor values
CREATE TABLE IF NOT EXISTS hardware_state (
    incubator_id INT NOT NULL PRIMARY KEY,
    temperature DECIMAL(5,2) DEFAULT NULL,
    humidity DECIMAL(5,2) DEFAULT NULL,
    device_status ENUM('online','offline') NOT NULL DEFAULT 'offline',
    current_temp DECIMAL(5,2) DEFAULT NULL,
    current_humidity DECIMAL(5,2) DEFAULT NULL,
    heater_on TINYINT(1) NOT NULL DEFAULT 0,
    heater_1_status TINYINT(1) NOT NULL DEFAULT 0,
    heater_2_status TINYINT(1) NOT NULL DEFAULT 0,
    heater_fan_status TINYINT(1) NOT NULL DEFAULT 0,
    exhaust_status TINYINT(1) NOT NULL DEFAULT 0,
    swing_on TINYINT(1) NOT NULL DEFAULT 0,
    swing_status TINYINT(1) NOT NULL DEFAULT 0,
    last_seen TIMESTAMP NULL DEFAULT NULL,
    last_active_at TIMESTAMP NULL DEFAULT NULL,
    last_server_sync TIMESTAMP NULL DEFAULT NULL,
    last_egg_turn_at DATETIME DEFAULT NULL,
    running_ops VARCHAR(255) DEFAULT NULL,
    wifi_status ENUM('connected','disconnected') NOT NULL DEFAULT 'connected',
    current_mode ENUM('idle','incubating','hatching') NOT NULL DEFAULT 'idle',
    active_session_name VARCHAR(150) DEFAULT NULL,
    swing_duration_sec INT NOT NULL DEFAULT 30,
    session_started_at DATETIME DEFAULT NULL,
    session_ends_at DATETIME DEFAULT NULL,
    session_completed_at DATETIME DEFAULT NULL,
    session_status ENUM('idle','running','completed') NOT NULL DEFAULT 'idle',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (incubator_id) REFERENCES incubators(id) ON DELETE CASCADE
);

-- ALERTS TABLE
CREATE TABLE IF NOT EXISTS alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    incubator_id INT DEFAULT NULL,
    batch_id INT DEFAULT NULL,
    alert_type ENUM('temp_high','temp_low','humidity_high','humidity_low','schedule_missed','hatch_due','system') DEFAULT 'system',
    message TEXT NOT NULL,
    severity ENUM('info','warning','danger') DEFAULT 'info',
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incubator_id) REFERENCES incubators(id) ON DELETE SET NULL
);

-- ACTIVITY LOGS
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role ENUM('admin','user') NOT NULL,
    user_id INT NOT NULL,
    action VARCHAR(255) NOT NULL,
    details TEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SEED DEFAULT ADMIN
INSERT INTO admins (full_name, email, password, status) VALUES
('Ghost Admin', 'admin@ghost.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active');
-- Default password: password

-- SEED SAMPLE USER
INSERT INTO users (full_name, email, password, phone, status) VALUES
('John Doe', 'user@ghost.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09171234567', 'active');
-- Default password: password

-- SEED INCUBATORS
INSERT INTO incubators (name, model, capacity, location, status, owner_id) VALUES
('Alpha Unit', 'GH-Pro 1000', 100, 'Farm House A', 'active', 1),
('Beta Unit', 'GH-Pro 500', 50, 'Farm House B', 'idle', 1),
('Gamma Unit', 'GH-Mini 200', 200, 'Greenhouse C', 'maintenance', 1);

-- SEED TEMPERATURE SETTINGS
INSERT INTO temperature_settings (incubator_id, target_temp, min_temp, max_temp, target_humidity, min_humidity, max_humidity) VALUES
(1, 37.50, 37.00, 38.00, 55.00, 50.00, 60.00),
(2, 37.50, 37.00, 38.00, 55.00, 50.00, 60.00),
(3, 37.50, 37.00, 38.00, 55.00, 50.00, 60.00);

-- SEED BATCHES
INSERT INTO batches (incubator_id, user_id, batch_name, egg_type, egg_count, start_date, expected_hatch_date, status) VALUES
(1, 1, 'Batch Alpha-01', 'Chicken', 85, CURDATE() - INTERVAL 10 DAY, CURDATE() + INTERVAL 11 DAY, 'incubating'),
(1, 1, 'Batch Alpha-02', 'Quail', 40, CURDATE() - INTERVAL 5 DAY, CURDATE() + INTERVAL 13 DAY, 'incubating'),
(2, 1, 'Batch Beta-01', 'Duck', 30, CURDATE() - INTERVAL 20 DAY, CURDATE() + INTERVAL 8 DAY, 'incubating');

-- SEED TEMP LOGS
INSERT INTO temperature_logs (incubator_id, temperature, humidity, recorded_by, recorded_at) VALUES
(1, 37.4, 54.5, 'auto', NOW() - INTERVAL 6 HOUR),
(1, 37.6, 55.2, 'auto', NOW() - INTERVAL 5 HOUR),
(1, 37.5, 55.0, 'auto', NOW() - INTERVAL 4 HOUR),
(1, 37.7, 55.8, 'auto', NOW() - INTERVAL 3 HOUR),
(1, 37.5, 54.9, 'auto', NOW() - INTERVAL 2 HOUR),
(1, 37.4, 55.1, 'auto', NOW() - INTERVAL 1 HOUR),
(1, 37.6, 55.3, 'auto', NOW());

-- SEED SCHEDULES
INSERT INTO schedules (incubator_id, batch_id, title, scheduled_date, scheduled_time, action_type, status, created_by_role, created_by_id) VALUES
(1, 1, 'Morning Egg Turning', CURDATE(), '06:00:00', 'turning', 'pending', 'admin', 1),
(1, 1, 'Midday Temperature Check', CURDATE(), '12:00:00', 'temperature_check', 'pending', 'admin', 1),
(1, 1, 'Evening Candling Session', CURDATE() + INTERVAL 1 DAY, '17:00:00', 'candling', 'pending', 'admin', 1),
(2, 3, 'Duck Batch Humidity Check', CURDATE(), '09:00:00', 'humidity_check', 'done', 'admin', 1);

-- SEED ALERTS
INSERT INTO alerts (incubator_id, alert_type, message, severity) VALUES
(1, 'temp_high', 'Temperature exceeded 38°C in Alpha Unit', 'warning'),
(3, 'system', 'Gamma Unit maintenance scheduled', 'info'),
(2, 'hatch_due', 'Batch Beta-01 expected to hatch in 8 days', 'info');
