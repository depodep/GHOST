/*
 * ============================================================
 *  GHOST Egg Incubator — ESP8266 Firmware  v2.0
 *
 *  Hardware:
 *    ESP8266 NodeMCU / Wemos D1 Mini
 *    DHT22    — temperature + humidity sensor (D4)
 *    Relay 1  (D5) → 2× PTC Heater in parallel
 *                     (PTC has built-in fan — no separate fan pin)
 *    Relay 2  (D6) → 3× Egg Swing motor in parallel
 *
 *  Libraries required (install via Library Manager):
 *    - DHT sensor library   by Adafruit
 *    - Adafruit Unified Sensor by Adafruit
 *    - ArduinoJson          v6.x by Benoit Blanchon
 *    - ESP8266WiFi          (bundled with ESP8266 board package)
 *    - ESP8266HTTPClient    (bundled with ESP8266 board package)
 * ============================================================
 */

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <EEPROM.h>
#include <DHT.h>
#include <ArduinoJson.h>

// ─────────────────────────────────────────────
//  ★  USER CONFIGURATION — EDIT THESE  ★
// ─────────────────────────────────────────────

// ─────────────────────────────────────────────
//  HOME NETWORK (Router WiFi)
// ─────────────────────────────────────────────
// ESP8266 connects to home WiFi to access server
const char* WIFI_SSID     = "Lia";
const char* WIFI_PASSWORD = "Liapaconnect11";

// ─────────────────────────────────────────────
//  SERVER CONFIGURATION (Laptop Server)
// ─────────────────────────────────────────────
// Laptop's IP on home WiFi network
// This is the ONLY configuration you need to change
const char* SERVER_IP     = "192.168.0.115";  // Laptop IP on HOME WiFi
const int   SERVER_PORT   = 80;               // Port of laptop server
const char* SERVER_BASE_PATH = "/GHOST";      // XAMPP project folder on server
const int   INCUBATOR_ID  = 1;                // Incubator ID for server identification

// ─────────────────────────────────────────────
//  LOCAL AP NETWORK (Optional - for debugging)
// ─────────────────────────────────────────────
// Can be disabled if not needed for local testing
const bool  ENABLE_AP_MODE = false;           // Set to true for local AP access
const char* AP_SSID       = "GHOST_Incubator";
const char* AP_PASSWORD   = "ghost2024pass";

// ─────────────────────────────────────────────
//  TEST MODE (for relay control via test.php)
// ─────────────────────────────────────────────
// Set to true: Disables auto thermostat/schedule logic, allows manual relay control only
// Set to false: Enables auto system logic (thermostat, schedules, server syncing)
const bool  TEST_MODE = true;  // ← Change to false when deploying for real operation

// ─────────────────────────────────────────────
//  EEPROM ADDRESSES FOR LOCAL STORAGE
// ─────────────────────────────────────────────
// Max EEPROM on ESP8266: 4096 bytes
#define EEPROM_SIZE         4096
#define EEPROM_TARGET_TEMP  0      // float (4 bytes)
#define EEPROM_MIN_TEMP     4      // float (4 bytes)
#define EEPROM_MAX_TEMP     8      // float (4 bytes)
#define EEPROM_TARGET_HUM   12     // float (4 bytes)
#define EEPROM_MIN_HUM      16     // float (4 bytes)
#define EEPROM_MAX_HUM      20     // float (4 bytes)
#define EEPROM_TURNING_INT  24     // int (4 bytes)
#define EEPROM_SESSION_NAME 28     // string (50 bytes) - batch name
#define EEPROM_SESSION_ID   78     // int (4 bytes) - session ID from server
#define EEPROM_INIT_FLAG    82     // byte (1 byte) - 0xFF = initialized

// ─────────────────────────────────────────────
//  PIN DEFINITIONS
// ─────────────────────────────────────────────
#define DHT_PIN        D3   // DHT22 data pin (temperature + humidity)
#define DHT_TYPE       DHT22

// Relay pin assignments (updated)
#define RELAY_HEATER_FAN   D4   // Heater fan
#define RELAY_HEATER_1     D5   // Heater element 1
#define RELAY_HEATER_2     D6   // Heater element 2
#define RELAY_EGGSWING     D7   // Egg swing motor
#define RELAY_EXHAUST      D8   // Exhaust fan / ventilation

// ─────────────────────────────────────────────
//  RELAY LOGIC
//  This hardware is wired as ACTIVE HIGH:
//    HIGH = relay energised (ON)
//    LOW  = relay off
// ─────────────────────────────────────────────
#define RELAY_ON   HIGH
#define RELAY_OFF  LOW

// ─────────────────────────────────────────────
//  TIMING  (milliseconds)
// ─────────────────────────────────────────────
#define SENSOR_INTERVAL      10000UL   // Read sensors every 10 s
#define LOG_INTERVAL         60000UL   // Log to server every 60 s
#define SETTINGS_INTERVAL    30000UL   // Fetch temp settings every 30 s
#define SCHEDULE_INTERVAL    30000UL   // Check turning schedules every 30 s
#define COMMAND_INTERVAL      5000UL   // Poll manual commands every 5 s
#define STATUS_INTERVAL       4000UL   // Send live heartbeat every 4 s
#define SWING_DURATION       30000UL   // Swing motors run 30 s per cycle
#define WIFI_RECONNECT_MS    10000UL   // Retry Wi-Fi every 10 s

// ─────────────────────────────────────────────
//  SENSOR & CLIENT OBJECTS
// ─────────────────────────────────────────────
DHT                    dht(DHT_PIN, DHT_TYPE);
WiFiClient             wifiClient;  // For server communication
HTTPClient             httpClient;  // For HTTP requests to server
ESP8266WebServer       testServer(80);  // HTTP server for test endpoints only

// ─────────────────────────────────────────────
//  LIVE SENSOR VALUES
// ─────────────────────────────────────────────
float currentTemp     = 0.0;
float currentHumidity = 0.0;
bool  tempOK          = false;
bool  humOK           = false;

// ─────────────────────────────────────────────
//  SESSION STATE (LOCAL - stored in EEPROM)
// ─────────────────────────────────────────────
// Modes: IDLE (waiting for params), RUNNING (session active), COMPLETED
enum SessionMode { MODE_IDLE, MODE_RUNNING, MODE_COMPLETED };
SessionMode sessionMode = MODE_IDLE;

// Session info
char  sessionName[50]   = "";           // Batch/session name
int   sessionId         = 0;            // From server
unsigned long sessionStartedAt = 0;     // Timestamp when started
unsigned long sessionEndsAt    = 0;     // Calculated end time
bool  hasValidParams    = false;        // True if EEPROM has saved params

// Parameters loaded from EEPROM (or received from server)
float savedTargetTemp   = 37.50;
float savedMinTemp      = 37.00;
float savedMaxTemp      = 38.00;
float savedTargetHum    = 55.00;
float savedMinHum       = 50.00;
float savedMaxHum       = 60.00;
int   savedTurningInt   = 8;

// ─────────────────────────────────────────────
//  RELAY STATE
// ─────────────────────────────────────────────
// Group + individual relay state flags
bool heaterGroupOn = false; // overall heater group state
bool heaterFanOn   = false;
bool heater1On     = false;
bool heater2On     = false;
bool eggswingOn    = false;
bool exhaustOn     = false;

// Manual override flags (set by dashboard commands)
bool heaterManualOverride = false;   // true = dashboard forced a state
bool swingManualOverride  = false;

// ─────────────────────────────────────────────
//  TIMERS (for local operation - offline mode)
// ─────────────────────────────────────────────
unsigned long lastSensorRead    = 0;
unsigned long lastScheduleFetch = 0;
unsigned long lastServerPost    = 0;
unsigned long lastSettingsFetch = 0;
unsigned long swingStartedAt    = 0;
unsigned long lastStatusPrint   = 0;

const char* getCurrentModeLabel() {
    if (TEST_MODE) return "TEST_MODE";
    if (sessionMode == MODE_RUNNING) return "INCUBATING";
    if (sessionMode == MODE_COMPLETED) return "COMPLETED";
    return "IDLE";
}

void printRelayStates(const char* tag) {
    Serial.printf("[%s] Relays: heater=%s fan=%s h1=%s h2=%s swing=%s exhaust=%s\n",
        tag,
        heaterGroupOn ? "ON" : "OFF",
        heaterFanOn ? "ON" : "OFF",
        heater1On ? "ON" : "OFF",
        heater2On ? "ON" : "OFF",
        eggswingOn ? "ON" : "OFF",
        exhaustOn ? "ON" : "OFF");
}

void printPollingStatus(const char* tag) {
    const char* wifiStatus = (WiFi.status() == WL_CONNECTED) ? "CONNECTED" : "DISCONNECTED";
    Serial.printf("[%s] WiFi=%s | Mode=%s | Temp=%.1fC | Hum=%.1f%%\n",
        tag, wifiStatus, getCurrentModeLabel(), currentTemp, currentHumidity);
    printRelayStates(tag);
}



// ─────────────────────────────────────────────
//  SETUP
// ─────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(300);

    Serial.println(F("\n========================================"));
    Serial.println(F("  GHOST Incubator — ESP8266 v2.0"));
    Serial.println(F("  STA MODE (Connecting to Lia)"));
    Serial.println(F("  DHT22 Temp/Humidity | PTC + Swing"));
    Serial.println(F("========================================\n"));

    // Initialize EEPROM
    EEPROM.begin(EEPROM_SIZE);
    
    // Relay pins — default OFF before anything else
    pinMode(RELAY_HEATER_FAN, OUTPUT);
    pinMode(RELAY_HEATER_1, OUTPUT);
    pinMode(RELAY_HEATER_2, OUTPUT);
    pinMode(RELAY_EGGSWING, OUTPUT);
    pinMode(RELAY_EXHAUST, OUTPUT);

    digitalWrite(RELAY_HEATER_FAN, RELAY_OFF);
    digitalWrite(RELAY_HEATER_1, RELAY_OFF);
    digitalWrite(RELAY_HEATER_2, RELAY_OFF);
    digitalWrite(RELAY_EGGSWING, RELAY_OFF);
    digitalWrite(RELAY_EXHAUST, RELAY_OFF);

    // Start sensor
    dht.begin();

    // Load saved parameters from EEPROM
    loadParametersFromEEPROM();
    
    // Check if EEPROM has valid data
    if (EEPROM.read(EEPROM_INIT_FLAG) == 0xFF) {
        hasValidParams = true;
        if (!TEST_MODE) {
            sessionMode = MODE_RUNNING;
        }
        Serial.println(F("[EEPROM] Valid parameters found!"));
        printSavedParameters();
    } else {
        hasValidParams = false;
        sessionMode = MODE_IDLE;
        Serial.println(F("[EEPROM] No saved parameters — waiting for server config"));
    }

    // Start WiFi AP (hotspot for laptop)
    startWiFiAP();

    // Setup test HTTP server endpoints
    setupTestEndpoints();
    testServer.begin();

    // First sensor reads
    readTemperature();
    readHumidity();
    
    Serial.printf("\n[System] Ready!\n");
    Serial.printf("[WiFi] Status: %s\n", (WiFi.status() == WL_CONNECTED) ? "CONNECTED" : "DISCONNECTED");
    Serial.printf("[Server] Base URL: http://%s:%d%s\n", SERVER_IP, SERVER_PORT, SERVER_BASE_PATH);
    if (TEST_MODE) {
        Serial.println(F("[Mode] TEST MODE (manual relay + DHT sync)"));
    } else {
        Serial.printf("[Mode] %s\n", getCurrentModeLabel());
    }
}

// ─────────────────────────────────────────────
//  MAIN LOOP
// ─────────────────────────────────────────────
void loop() {
    // Handle test endpoints (non-blocking)
    testServer.handleClient();
    
    unsigned long now = millis();

    // ────────────────────────────────────────────────────────────
    //  TEST MODE: Always run manual relay + DHT sync loop
    // ────────────────────────────────────────────────────────────
    if (TEST_MODE) {
        if (now - lastSensorRead >= SENSOR_INTERVAL) {
            lastSensorRead = now;
            readTemperature();
            readHumidity();
            Serial.printf("[TEST_DHT] Temp: %0.1f°C, Humidity: %0.1f%%\n", currentTemp, currentHumidity);
        }

        // Post DHT data to server every 5 seconds
        static unsigned long lastTestPost = 0;
        if (now - lastTestPost >= 5000) {
            lastTestPost = now;
            postTestDHTToServer();
        }

        // Poll server for relay commands every 2 seconds
        static unsigned long lastTestPoll = 0;
        if (now - lastTestPoll >= 2000) {
            lastTestPoll = now;
            pollServerForTestCommands();
        }

        if (now - lastStatusPrint >= STATUS_INTERVAL) {
            lastStatusPrint = now;
            printPollingStatus("TEST_POLL");
        }

        delay(100);
        return;
    }

    // ── IDLE MODE: Waiting for parameters from server ──
    if (sessionMode == MODE_IDLE) {
        if (now - lastSensorRead >= SENSOR_INTERVAL) {
            lastSensorRead = now;
            readTemperature();
            readHumidity();
        }
        // Heater OFF during idle
        if (heaterGroupOn) setHeater(false);
        if (eggswingOn) setSwing(false);
        if (now - lastSettingsFetch >= SETTINGS_INTERVAL) {
            lastSettingsFetch = now;
            Serial.println(F("[IDLE] Fetching parameters from server..."));
            fetchParametersFromServer();
        }

        if (now - lastStatusPrint >= STATUS_INTERVAL) {
            lastStatusPrint = now;
            printPollingStatus("IDLE_POLL");
        }

        delay(100);
        return;  // Skip everything else, just wait
    }

    // ── SESSION RUNNING: Use saved parameters for offline operation ──
    if (sessionMode == MODE_RUNNING) {
        
        // ────────────────────────────────────────────────────────────
        //  NORMAL MODE: Full automatic system operation
        // ────────────────────────────────────────────────────────────
        
        // Check if session should end (use saved calculated endTime)
        if (now >= sessionEndsAt) {
            sessionMode = MODE_COMPLETED;
            setHeater(false);
            setSwing(false);
            Serial.println(F("[Session] COMPLETED!"));
            return;
        }

        // ── Read sensors ──────────────────────────
        if (now - lastSensorRead >= SENSOR_INTERVAL) {
            lastSensorRead = now;
            readTemperature();
            readHumidity();
        }

        // ── Heater thermostat control (using saved parameters) ─────────────
        if (tempOK && !heaterManualOverride) {
            // Use savedTargetTemp, savedMinTemp, savedMaxTemp
            if (currentTemp < savedMinTemp) {
                setHeater(true);
            } else if (currentTemp > savedMaxTemp) {
                setHeater(false);
            }
        } else if (!heaterManualOverride && heaterGroupOn) {
            setHeater(false);
        }

        // ── Auto-stop swing after SWING_DURATION ──
        if (eggswingOn && !swingManualOverride) {
            if (now - swingStartedAt >= SWING_DURATION) {
                setSwing(false);
                Serial.println(F("[Swing] Auto-stop — cycle complete"));
            }
        }

        // ── Check turning schedule (every 30 s) ──
        if (now - lastScheduleFetch >= SCHEDULE_INTERVAL) {
            lastScheduleFetch = now;
            // Would normally check schedule, but in offline mode
            // we could run a simple turn schedule based on savedTurningInt
            // For now, just log that we're running
            Serial.printf("[Session] Running: Temp=%0.1f°C (target %0.1f°C)\n", currentTemp, savedTargetTemp);
        }

        // ── Post sensor data to server (every 60 s) ──
        if (now - lastServerPost >= LOG_INTERVAL) {
            lastServerPost = now;
            postSensorDataToServer();
        }

        // ── Fetch updated settings from server (every 30 s) ──
        if (now - lastSettingsFetch >= SETTINGS_INTERVAL) {
            lastSettingsFetch = now;
            fetchParametersFromServer();
        }

        if (now - lastStatusPrint >= STATUS_INTERVAL) {
            lastStatusPrint = now;
            printPollingStatus("ACTUAL_POLL");
        }
    }

    delay(100);
}

// ─────────────────────────────────────────────
//  WIFI SETUP (Connect to Home Network)
// ─────────────────────────────────────────────
void startWiFiAP() {
    // Connect to home network (STA mode)
    WiFi.mode(WIFI_STA);
    Serial.printf("[WiFi] Connecting to: %s\n", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
        delay(500);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        Serial.println(F("\n[WiFi] Connected!"));
        Serial.println(F("╔════════════════════════════════════════════════╗"));
        Serial.println(F("║  CONNECTED TO HOME NETWORK (STA MODE)         ║"));
        Serial.println(F("╠════════════════════════════════════════════════╣"));
        Serial.printf("   ║  SSID: %s%-33s ║\n", WIFI_SSID, "");
        Serial.printf("   ║  IP:   %s%-28s ║\n", WiFi.localIP().toString().c_str(), "");
        Serial.println(F("║                                                ║"));
        Serial.println(F("║  Server: http://[SERVER_IP]/GHOST              ║"));
        Serial.println(F("║  Test:   http://[SERVER_IP]/api/test/status    ║"));
        Serial.println(F("║                                                ║"));
        Serial.println(F("╚════════════════════════════════════════════════╝\n"));
    } else {
        Serial.println(F("\n[WiFi] FAILED to connect - will retry"));
         
    }
    
     if (ENABLE_AP_MODE) {
        WiFi.softAP(AP_SSID, AP_PASSWORD);
        Serial.printf("[AP] Also running AP mode: %s\n", AP_SSID);
    }
}



// ─────────────────────────────────────────────
//  TEST ENDPOINTS SETUP (For test.php)
// ─────────────────────────────────────────────
void setupTestEndpoints() {
     testServer.on("/api/test/status", HTTP_GET, []() {
        StaticJsonDocument<384> doc;
        doc["temp"] = currentTemp;
        doc["humidity"] = currentHumidity;
        // Individual relay states
        doc["heater_group"] = heaterGroupOn;
        doc["heater_fan"] = heaterFanOn;
        doc["heater_1"] = heater1On;
        doc["heater_2"] = heater2On;
        doc["eggswing"] = eggswingOn;
        doc["exhaust"] = exhaustOn;
        doc["mode"] = (sessionMode == MODE_IDLE) ? "IDLE" : 
                      (sessionMode == MODE_RUNNING) ? "RUNNING" : "COMPLETED";
        doc["session_id"] = sessionId;

        String response;
        serializeJson(doc, response);
        testServer.send(200, "application/json", response);
    });

     testServer.on("/api/test/relay", HTTP_POST, []() {
        if (!testServer.hasArg("relay") || !testServer.hasArg("state")) {
            testServer.send(400, "application/json", "{\"success\":false,\"error\":\"Missing parameters\"}");
            return;
        }
        
        String relay = testServer.arg("relay");
        bool state = testServer.arg("state").toInt() != 0;
        
        // Control relay based on name
        if (relay == "heater") {
            // group: all heater relays
            setHeater(state);
            Serial.printf("[TEST] Heater group set to %s\n", state ? "ON" : "OFF");
            testServer.send(200, "application/json", "{\"success\":true,\"relay\":\"heater\"}");
        } else if (relay == "heater_fan") {
            heaterFanOn = state;
            digitalWrite(RELAY_HEATER_FAN, state ? RELAY_ON : RELAY_OFF);
            Serial.printf("[TEST] Heater fan set to %s\n", state ? "ON" : "OFF");
            testServer.send(200, "application/json", "{\"success\":true,\"relay\":\"heater_fan\"}");
        } else if (relay == "heater_1") {
            heater1On = state;
            digitalWrite(RELAY_HEATER_1, state ? RELAY_ON : RELAY_OFF);
            Serial.printf("[TEST] Heater 1 set to %s\n", state ? "ON" : "OFF");
            testServer.send(200, "application/json", "{\"success\":true,\"relay\":\"heater_1\"}");
        } else if (relay == "heater_2") {
            heater2On = state;
            digitalWrite(RELAY_HEATER_2, state ? RELAY_ON : RELAY_OFF);
            Serial.printf("[TEST] Heater 2 set to %s\n", state ? "ON" : "OFF");
            testServer.send(200, "application/json", "{\"success\":true,\"relay\":\"heater_2\"}");
        } else if (relay == "eggswing") {
            setSwing(state);
            Serial.printf("[TEST] Egg swing set to %s\n", state ? "ON" : "OFF");
            testServer.send(200, "application/json", "{\"success\":true,\"relay\":\"eggswing\"}");
        } else if (relay == "exhaust") {
            setExhaust(state);
            Serial.printf("[TEST] Exhaust set to %s\n", state ? "ON" : "OFF");
            testServer.send(200, "application/json", "{\"success\":true,\"relay\":\"exhaust\"}");
        } else {
            testServer.send(400, "application/json", "{\"success\":false,\"error\":\"Unknown relay\"}");
        }
    });

    // 404 handler for test server
    testServer.onNotFound([]() {
        testServer.send(404, "application/json", "{\"error\":\"Test endpoint not found\"}");
    });
    
    Serial.println(F("[Setup] Test endpoints registered on /api/test/*"));
}
// ─────────────────────────────────────────────
//  TEST MODE: Poll server for relay commands
// ─────────────────────────────────────────────
void pollServerForTestCommands() {
    String url = "http://";
    url += SERVER_IP;
    url += ":";
    url += SERVER_PORT;
    url += SERVER_BASE_PATH;
    url += "/ajax/hardware_api.php?action=test_mode_get_relay&incubator_id=";
    url += INCUBATOR_ID;
    
    httpClient.begin(wifiClient, url);
    int httpCode = httpClient.GET();
    
    if (httpCode == HTTP_CODE_OK) {
        String payload = httpClient.getString();
        StaticJsonDocument<256> doc;
        auto err = deserializeJson(doc, payload);
        if (!err && doc["success"] == true && doc.containsKey("relay") && doc.containsKey("state")) {
            String relay = doc["relay"];
            bool state = doc["state"];

            if (relay == "heater") {
                setHeater(state);
                Serial.printf("[TEST CMD] Heater %s\n", state ? "ON" : "OFF");
            } else if (relay == "heater_fan") {
                heaterFanOn = state;
                digitalWrite(RELAY_HEATER_FAN, state ? RELAY_ON : RELAY_OFF);
                Serial.printf("[TEST CMD] Heater fan %s\n", state ? "ON" : "OFF");
            } else if (relay == "heater_1") {
                heater1On = state;
                digitalWrite(RELAY_HEATER_1, state ? RELAY_ON : RELAY_OFF);
                Serial.printf("[TEST CMD] Heater 1 %s\n", state ? "ON" : "OFF");
            } else if (relay == "heater_2") {
                heater2On = state;
                digitalWrite(RELAY_HEATER_2, state ? RELAY_ON : RELAY_OFF);
                Serial.printf("[TEST CMD] Heater 2 %s\n", state ? "ON" : "OFF");
            } else if (relay == "eggswing") {
                setSwing(state);
                Serial.printf("[TEST CMD] Egg swing %s\n", state ? "ON" : "OFF");
            } else if (relay == "exhaust") {
                setExhaust(state);
                Serial.printf("[TEST CMD] Exhaust %s\n", state ? "ON" : "OFF");
            }

            printRelayStates("TEST_CMD");
            postTestDHTToServer();
        } else if (!err && doc.containsKey("error")) {
            Serial.printf("[TEST CMD] API error: %s\n", ((const char*)doc["error"]));
        }
    } else {
        Serial.printf("[TEST CMD] Poll failed: HTTP %d\n", httpCode);
    }
    
    httpClient.end();
}

// ─────────────────────────────────────────────
//  TEST MODE: POST DHT data to server
// ─────────────────────────────────────────────
void postTestDHTToServer() {
    String url = "http://";
    url += SERVER_IP;
    url += ":";
    url += SERVER_PORT;
    url += SERVER_BASE_PATH;
    url += "/ajax/hardware_api.php";
    
    // Build form data
    String postData = "action=test_mode_set_dht&incubator_id=" + String(INCUBATOR_ID);
    postData += "&temp=" + String(currentTemp, 2);
    postData += "&humidity=" + String(currentHumidity, 2);
    postData += "&heater_on=" + String(heaterGroupOn ? 1 : 0);
    postData += "&heater_fan_status=" + String(heaterFanOn ? 1 : 0);
    postData += "&heater_1_status=" + String(heater1On ? 1 : 0);
    postData += "&heater_2_status=" + String(heater2On ? 1 : 0);
    postData += "&swing_on=" + String(eggswingOn ? 1 : 0);
    postData += "&swing_status=" + String(eggswingOn ? 1 : 0);
    postData += "&exhaust_status=" + String(exhaustOn ? 1 : 0);
    
    httpClient.begin(wifiClient, url);
    httpClient.addHeader("Content-Type", "application/x-www-form-urlencoded");
    int httpCode = httpClient.POST(postData);
    
    if (httpCode > 0) {
        String response = httpClient.getString();
        Serial.printf("[TEST_DHT] Posted: T=%.1f°C, H=%.1f%% (HTTP %d) %s\n", currentTemp, currentHumidity, httpCode, response.c_str());
    } else {
        Serial.printf("[TEST_DHT] POST failed: %s\n", httpClient.errorToString(httpCode).c_str());
    }
    
    httpClient.end();
}

// ─────────────────────────────────────────────
//  POST SENSOR DATA TO SERVER (LAPTOP)
// ─────────────────────────────────────────────
void postSensorDataToServer() {
    // Prepare JSON payload
    StaticJsonDocument<384> doc;
    doc["incubator_id"] = INCUBATOR_ID;
    doc["temp"] = currentTemp;
    doc["humidity"] = currentHumidity;
    doc["heater_group"] = heaterGroupOn;
    doc["heater_fan"] = heaterFanOn;
    doc["heater_1"] = heater1On;
    doc["heater_2"] = heater2On;
    doc["eggswing"] = eggswingOn;
    doc["exhaust"] = exhaustOn;
    doc["mode"] = (sessionMode == MODE_IDLE) ? "IDLE" : 
                  (sessionMode == MODE_RUNNING) ? "RUNNING" : "COMPLETED";
    doc["session_id"] = sessionId;
    
    String payload;
    serializeJson(doc, payload);
    
    // Build HTTP URL (via STA, not AP)
    String url = "http://";
    url += SERVER_IP;
    url += ":";
    url += SERVER_PORT;
    url += SERVER_BASE_PATH;
    url += "/api/log_temperature";
    
    httpClient.begin(wifiClient, url);
    httpClient.addHeader("Content-Type", "application/json");
    
    int httpCode = httpClient.POST(payload);
    
    if (httpCode > 0) {
        Serial.printf("[Server] POST response: %d\n", httpCode);
        if (httpCode == HTTP_CODE_OK || httpCode == HTTP_CODE_CREATED) {
            Serial.println(F("[Server] Data sent successfully"));
        } else {
            Serial.printf("[Server] Unexpected response code: %d\n", httpCode);
        }
    } else {
        Serial.printf("[Server] POST failed: %s\n", httpClient.errorToString(httpCode).c_str());
    }
    
    httpClient.end();
}

// ─────────────────────────────────────────────
//  FETCH PARAMETERS FROM SERVER
// ─────────────────────────────────────────────
void fetchParametersFromServer() {
    String url = "http://";
    url += SERVER_IP;
    url += ":";
    url += SERVER_PORT;
    url += SERVER_BASE_PATH;
    url += "/api/get_settings?incubator_id=";
    url += INCUBATOR_ID;
    
    httpClient.begin(wifiClient, url);
    
    int httpCode = httpClient.GET();
    
    if (httpCode == HTTP_CODE_OK) {
        String payload = httpClient.getString();
        StaticJsonDocument<256> doc;
        auto err = deserializeJson(doc, payload);
        
        if (!err) {
            if (doc.containsKey("target_temp")) savedTargetTemp = doc["target_temp"];
            if (doc.containsKey("min_temp")) savedMinTemp = doc["min_temp"];
            if (doc.containsKey("max_temp")) savedMaxTemp = doc["max_temp"];
            if (doc.containsKey("target_hum")) savedTargetHum = doc["target_hum"];
            if (doc.containsKey("min_hum")) savedMinHum = doc["min_hum"];
            if (doc.containsKey("max_hum")) savedMaxHum = doc["max_hum"];
            if (doc.containsKey("turning_interval")) savedTurningInt = doc["turning_interval"];
            if (doc.containsKey("session_name")) strncpy(sessionName, doc["session_name"], 49);
            if (doc.containsKey("session_id")) sessionId = doc["session_id"];
            
            saveParametersToEEPROM();
            hasValidParams = true;
            if (sessionMode == MODE_IDLE && !TEST_MODE) {
                sessionMode = MODE_RUNNING;
                Serial.println(F("[Mode] Switched to INCUBATING (parameters loaded)"));
            }
            Serial.println(F("[Server] Parameters fetched and saved!"));
        } else {
            Serial.println(F("[Server] JSON parse error"));
        }
    } else {
        Serial.printf("[Server] GET failed: %d\n", httpCode);
    }
    
    httpClient.end();
}

// ─────────────────────────────────────────────
//  EEPROM FUNCTIONS
// ─────────────────────────────────────────────
void saveParametersToEEPROM() {
    // Write floats (4 bytes each)
    EEPROM.put(EEPROM_TARGET_TEMP, savedTargetTemp);
    EEPROM.put(EEPROM_MIN_TEMP, savedMinTemp);
    EEPROM.put(EEPROM_MAX_TEMP, savedMaxTemp);
    EEPROM.put(EEPROM_TARGET_HUM, savedTargetHum);
    EEPROM.put(EEPROM_MIN_HUM, savedMinHum);
    EEPROM.put(EEPROM_MAX_HUM, savedMaxHum);
    
    // Write int
    EEPROM.put(EEPROM_TURNING_INT, savedTurningInt);
    
    // Write session name
    for (int i = 0; i < 50; i++) {
        EEPROM.write(EEPROM_SESSION_NAME + i, sessionName[i]);
        if (sessionName[i] == '\0') break;
    }
    
    // Write session ID
    EEPROM.put(EEPROM_SESSION_ID, sessionId);
    
    // Mark as initialized
    EEPROM.write(EEPROM_INIT_FLAG, 0xFF);
    
    EEPROM.commit();
    Serial.println(F("[EEPROM] Parameters saved!"));
}

void loadParametersFromEEPROM() {
    if (EEPROM.read(EEPROM_INIT_FLAG) != 0xFF) {
        Serial.println(F("[EEPROM] Not initialized yet"));
        return;
    }
    
    EEPROM.get(EEPROM_TARGET_TEMP, savedTargetTemp);
    EEPROM.get(EEPROM_MIN_TEMP, savedMinTemp);
    EEPROM.get(EEPROM_MAX_TEMP, savedMaxTemp);
    EEPROM.get(EEPROM_TARGET_HUM, savedTargetHum);
    EEPROM.get(EEPROM_MIN_HUM, savedMinHum);
    EEPROM.get(EEPROM_MAX_HUM, savedMaxHum);
    EEPROM.get(EEPROM_TURNING_INT, savedTurningInt);
    
    // Load session name
    char name[50] = {0};
    for (int i = 0; i < 50; i++) {
        name[i] = EEPROM.read(EEPROM_SESSION_NAME + i);
        if (name[i] == '\0') break;
    }
    strncpy(sessionName, name, 49);
    
    EEPROM.get(EEPROM_SESSION_ID, sessionId);
}

void printSavedParameters() {
    Serial.printf("[Parameters] Target:%.1f°C (%.1f-%.1f)\n", savedTargetTemp, savedMinTemp, savedMaxTemp);
    Serial.printf("[Parameters] Humidity:%.1f%% (%.1f-%.1f)\n", savedTargetHum, savedMinHum, savedMaxHum);
    Serial.printf("[Parameters] Turning interval: %d hours\n", savedTurningInt);
    Serial.printf("[Parameters] Session: %s (ID:%d)\n", sessionName, sessionId);
}

// ─────────────────────────────────────────────
//  READ TEMPERATURE  (DHT22)
// ─────────────────────────────────────────────
void readTemperature() {
    float t = dht.readTemperature();

    if (isnan(t)) {
        tempOK = false;
        Serial.println(F("[DHT22] Temperature read failed"));
        return;
    }

    currentTemp = t;
    tempOK      = true;
    Serial.printf("[DHT22] Temperature: %.2f°C\n", currentTemp);
}

// ─────────────────────────────────────────────
//  READ HUMIDITY  (DHT22)
// ─────────────────────────────────────────────
void readHumidity() {
    float h = dht.readHumidity();
    if (isnan(h)) {
        humOK = false;
        Serial.println(F("[DHT22] Humidity read failed"));
        return;
    }
    currentHumidity = h;
    humOK           = true;
    Serial.printf("[DHT22]  Humidity:    %.2f%%\n", currentHumidity);
}

void controlHeater() {
    if (currentTemp < savedMinTemp && !heaterGroupOn) {
        setHeater(true);
        Serial.printf("[Heater] ON  — %.2f°C < %.2f°C\n", currentTemp, savedMinTemp);
    } else if (currentTemp >= savedMaxTemp && heaterGroupOn) {
        setHeater(false);
        Serial.printf("[Heater] OFF — %.2f°C >= %.2f°C\n", currentTemp, savedMaxTemp);
    }
}

// ─────────────────────────────────────────────
//  RELAY SETTERS
// ─────────────────────────────────────────────
void setHeater(bool on) {
    heaterGroupOn = on;
    heaterFanOn = on;
    heater1On = on;
    heater2On = on;
    digitalWrite(RELAY_HEATER_FAN, on ? RELAY_ON : RELAY_OFF);
    digitalWrite(RELAY_HEATER_1, on ? RELAY_ON : RELAY_OFF);
    digitalWrite(RELAY_HEATER_2, on ? RELAY_ON : RELAY_OFF);
}

void setSwing(bool on) {
    eggswingOn = on;
    if (on) swingStartedAt = millis();
    digitalWrite(RELAY_EGGSWING, on ? RELAY_ON : RELAY_OFF);
}

void setExhaust(bool on) {
    exhaustOn = on;
    digitalWrite(RELAY_EXHAUST, on ? RELAY_ON : RELAY_OFF);
}

