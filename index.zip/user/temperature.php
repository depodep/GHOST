<?php
$pageTitle = 'Temperature Monitor';
$pageSubtitle = 'View live temperature and humidity readings';
$activePage = 'temperature';
require_once 'header.php';
$pdo = getDB();
$uid = $_SESSION['user_id'];
$incubators = $pdo->prepare("SELECT i.*, ts.target_temp,ts.min_temp,ts.max_temp,ts.target_humidity FROM incubators i LEFT JOIN temperature_settings ts ON i.id=ts.incubator_id JOIN batches b ON b.incubator_id=i.id WHERE b.user_id=? GROUP BY i.id"); $incubators->execute([$uid]); $incubators = $incubators->fetchAll();
?>
<?php foreach($incubators as $inc): ?>
<?php
$logs = $pdo->prepare("SELECT temperature,humidity,recorded_by,DATE_FORMAT(recorded_at,'%b %d %H:%i') as lbl FROM temperature_logs WHERE incubator_id=? ORDER BY recorded_at DESC LIMIT 12");
$logs->execute([$inc['id']]); $logs = array_reverse($logs->fetchAll());
$latest = end($logs); reset($logs);
?>
<div class="ghost-panel mb-3">
  <div class="ghost-panel-header d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-3">
      <span style="font-size:1.4rem;">🌡️</span>
      <div>
        <span class="ghost-panel-title"><?= htmlspecialchars($inc['name']) ?></span>
        <div style="font-size:.75rem;color:var(--ghost-muted);margin-top:2px;">Target: <span style="color:var(--ghost-amber)"><?= $inc['target_temp'] ?>°C</span> · <?= $inc['target_humidity'] ?>% humidity</div>
      </div>
    </div>
    <div class="d-flex align-items-center gap-3">
      <?php if($latest): ?>
        <div style="text-align:right;"><div style="font-family:'Bebas Neue',sans-serif;font-size:2rem;color:var(--ghost-amber);line-height:1;"><?= $latest['temperature'] ?>°C</div><div style="font-size:.72rem;color:var(--ghost-muted);">Current Temp</div></div>
        <div style="text-align:right;"><div style="font-family:'Bebas Neue',sans-serif;font-size:2rem;color:var(--ghost-blue);line-height:1;"><?= $latest['humidity'] ?>%</div><div style="font-size:.72rem;color:var(--ghost-muted);">Humidity</div></div>
      <?php endif; ?>
      <button class="btn-ghost btn-ghost-sm" onclick="logReading(<?= $inc['id'] ?>)"><i class="fas fa-plus me-1"></i>Log</button>
    </div>
  </div>
  <div class="ghost-panel-body">
    <?php if(count($logs) > 1): ?>
    <canvas id="chart_<?= $inc['id'] ?>" height="100"></canvas>
    <script>
    new Chart(document.getElementById('chart_<?= $inc['id'] ?>'),{
      type:'line',
      data:{labels:<?= json_encode(array_column($logs,'lbl')) ?>,datasets:[
        {label:'Temp °C',yAxisID:'y',data:<?= json_encode(array_column($logs,'temperature')) ?>,borderColor:'#f5a623',backgroundColor:'rgba(245,166,35,.06)',tension:.4,pointRadius:3,borderWidth:2,fill:true},
        {label:'Humidity %',yAxisID:'y2',data:<?= json_encode(array_column($logs,'humidity')) ?>,borderColor:'#3b82f6',backgroundColor:'rgba(59,130,246,.05)',tension:.4,pointRadius:3,borderWidth:2,fill:true}
      ]},
      options:{responsive:true,plugins:{legend:{labels:{boxWidth:10,font:{size:11}}}},scales:{x:{grid:{color:'rgba(255,255,255,.04)'},ticks:{font:{size:9},maxTicksLimit:6}},y:{grid:{color:'rgba(255,255,255,.04)'},min:35,max:40,ticks:{font:{size:10},callback:v=>v+'°C'}},y2:{position:'right',grid:{display:false},ticks:{font:{size:10},callback:v=>v+'%'}}}}
    });
    </script>
    <?php else: ?>
    <div style="text-align:center;padding:20px;color:var(--ghost-muted);font-size:.88rem;">No readings logged yet. Start logging to see the chart.</div>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>
<?php if(empty($incubators)): ?>
<div style="text-align:center;padding:60px;color:var(--ghost-muted);"><div style="font-size:3rem;margin-bottom:16px;">🌡️</div><div>No incubators assigned to your batches yet.</div></div>
<?php endif; ?>

<!-- LOG MODAL -->
<div class="modal fade modal-ghost" id="logModal" tabindex="-1">
  <div class="modal-dialog modal-sm modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">📝 Log Reading</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" style="padding:24px;">
        <input type="hidden" id="lr_inc_id">
        <div class="mb-3"><label class="form-label-ghost">Temperature (°C)</label><input type="number" step="0.1" class="form-control-ghost" id="lr_temp" placeholder="37.5"></div>
        <div><label class="form-label-ghost">Humidity (%)</label><input type="number" step="0.1" class="form-control-ghost" id="lr_hum" placeholder="55.0"></div>
      </div>
      <div class="modal-footer"><button class="btn-outline-ghost" data-bs-dismiss="modal">Cancel</button><button class="btn-ghost" onclick="saveReading()"><i class="fas fa-save me-1"></i>Save</button></div>
    </div>
  </div>
</div>
<script>
function logReading(id){$('#lr_inc_id').val(id);new bootstrap.Modal(document.getElementById('logModal')).show();}
function saveReading(){
  showLoader('Saving Reading…');
  $.ajax({url:'../ajax/user_temperature.php',method:'POST',data:{action:'log_temp',incubator_id:$('#lr_inc_id').val(),temperature:$('#lr_temp').val(),humidity:$('#lr_hum').val()},dataType:'json',
    success:r=>{hideLoader();if(r.success){showToast('Reading saved!');setTimeout(()=>location.reload(),700);}else showToast(r.message,'error');},
    error:()=>{hideLoader();showToast('Server error.','error');}
  });
}
</script>
<?php require_once 'footer.php'; ?>
