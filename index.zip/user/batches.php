<?php
$pageTitle = 'My Batches';
$pageSubtitle = 'Track and manage your egg batches';
$activePage = 'batches';
require_once 'header.php';
$pdo = getDB();
$uid = $_SESSION['user_id'];
$batches = $pdo->prepare("SELECT b.*, i.name as incubator_name FROM batches b JOIN incubators i ON b.incubator_id=i.id WHERE b.user_id=? ORDER BY b.created_at DESC"); $batches->execute([$uid]); $batches = $batches->fetchAll();
$incubators = $pdo->query("SELECT id,name FROM incubators WHERE status='active'")->fetchAll();
?>
<div class="d-flex justify-content-end mb-4">
  <button class="btn-ghost" data-bs-toggle="modal" data-bs-target="#addBatchModal"><i class="fas fa-plus me-2"></i>New Batch</button>
</div>
<div class="ghost-panel">
  <div class="ghost-panel-header"><span class="ghost-panel-title">🥚 All My Batches</span></div>
  <div class="ghost-panel-body p-0">
    <table class="ghost-table">
      <thead><tr><th>Batch Name</th><th>Incubator</th><th>Type</th><th>Eggs</th><th>Start</th><th>Hatch Date</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach($batches as $b): $days=max(0,round((strtotime($b['expected_hatch_date'])-time())/86400)); ?>
        <tr>
          <td><div style="font-weight:600;color:white;"><?= htmlspecialchars($b['batch_name']) ?></div><?php if($b['notes']): ?><div style="font-size:.72rem;color:var(--ghost-muted);"><?= substr(htmlspecialchars($b['notes']),0,40) ?>...</div><?php endif; ?></td>
          <td style="font-size:.85rem;"><?= htmlspecialchars($b['incubator_name']) ?></td>
          <td style="font-size:.82rem;color:var(--ghost-muted);"><?= $b['egg_type'] ?></td>
          <td style="font-weight:600;"><?= $b['egg_count'] ?></td>
          <td style="font-size:.82rem;color:var(--ghost-muted);"><?= date('M j, Y',strtotime($b['start_date'])) ?></td>
          <td><div style="font-size:.85rem;"><?= date('M j, Y',strtotime($b['expected_hatch_date'])) ?></div><div style="font-size:.72rem;color:<?= $days<=3&&$b['status']=='incubating'?'#f87171':'var(--ghost-muted)' ?>;"><?= $b['status']=='incubating'?($days>0?$days.' days left':'Hatch day!'):'' ?></div></td>
          <td><span class="badge-<?= $b['status'] ?>"><?= $b['status'] ?></span></td>
          <td><div class="d-flex gap-2">
            <button class="btn-edit-ghost" onclick="editBatch(<?= htmlspecialchars(json_encode($b)) ?>)"><i class="fas fa-pen"></i></button>
            <button class="btn-danger-ghost" onclick="deleteBatch(<?= $b['id'] ?>)"><i class="fas fa-trash"></i></button>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ADD BATCH MODAL -->
<div class="modal fade modal-ghost" id="addBatchModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title"><i class="fas fa-plus-circle me-2" style="color:var(--ghost-blue)"></i>Start New Batch</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" style="padding:24px;">
        <div class="row g-3">
          <div class="col-12"><label class="form-label-ghost">Batch Name</label><input type="text" class="form-control-ghost" id="ab_name" placeholder="e.g. Batch Alpha-03"></div>
          <div class="col-md-6"><label class="form-label-ghost">Incubator</label><select class="form-select-ghost" id="ab_incubator"><option value="">Select Incubator</option><?php foreach($incubators as $i): ?><option value="<?= $i['id'] ?>"><?= htmlspecialchars($i['name']) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-6"><label class="form-label-ghost">Egg Type</label><select class="form-select-ghost" id="ab_type"><option>Chicken</option><option>Duck</option><option>Quail</option><option>Turkey</option><option>Goose</option><option>Other</option></select></div>
          <div class="col-md-4"><label class="form-label-ghost">Egg Count</label><input type="number" class="form-control-ghost" id="ab_count" placeholder="e.g. 50"></div>
          <div class="col-md-4"><label class="form-label-ghost">Start Date</label><input type="date" class="form-control-ghost" id="ab_start" value="<?= date('Y-m-d') ?>"></div>
          <div class="col-md-4"><label class="form-label-ghost">Expected Hatch</label><input type="date" class="form-control-ghost" id="ab_hatch" value="<?= date('Y-m-d',strtotime('+21 days')) ?>"></div>
          <div class="col-12"><label class="form-label-ghost">Notes</label><textarea class="form-control-ghost" id="ab_notes" rows="2" placeholder="Optional notes..."></textarea></div>
        </div>
      </div>
      <div class="modal-footer"><button class="btn-outline-ghost" data-bs-dismiss="modal">Cancel</button><button class="btn-ghost" onclick="addBatch()"><i class="fas fa-save me-2"></i>Start Batch</button></div>
    </div>
  </div>
</div>

<!-- EDIT BATCH MODAL -->
<div class="modal fade modal-ghost" id="editBatchModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title"><i class="fas fa-edit me-2" style="color:var(--ghost-blue)"></i>Edit Batch</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" style="padding:24px;">
        <input type="hidden" id="eb_id">
        <div class="row g-3">
          <div class="col-12"><label class="form-label-ghost">Batch Name</label><input type="text" class="form-control-ghost" id="eb_name"></div>
          <div class="col-md-6"><label class="form-label-ghost">Egg Type</label><select class="form-select-ghost" id="eb_type"><option>Chicken</option><option>Duck</option><option>Quail</option><option>Turkey</option><option>Goose</option><option>Other</option></select></div>
          <div class="col-md-6"><label class="form-label-ghost">Egg Count</label><input type="number" class="form-control-ghost" id="eb_count"></div>
          <div class="col-md-6"><label class="form-label-ghost">Expected Hatch</label><input type="date" class="form-control-ghost" id="eb_hatch"></div>
          <div class="col-md-6"><label class="form-label-ghost">Status</label><select class="form-select-ghost" id="eb_status"><option value="incubating">Incubating</option><option value="hatched">Hatched</option><option value="failed">Failed</option><option value="cancelled">Cancelled</option></select></div>
          <div class="col-12"><label class="form-label-ghost">Notes</label><textarea class="form-control-ghost" id="eb_notes" rows="2"></textarea></div>
        </div>
      </div>
      <div class="modal-footer"><button class="btn-outline-ghost" data-bs-dismiss="modal">Cancel</button><button class="btn-ghost" onclick="updateBatch()"><i class="fas fa-save me-2"></i>Update</button></div>
    </div>
  </div>
</div>

<script>
function addBatch(){
  showLoader('Starting Batch…');
  $.ajax({url:'../ajax/user_batches.php',method:'POST',data:{action:'add',name:$('#ab_name').val(),incubator_id:$('#ab_incubator').val(),egg_type:$('#ab_type').val(),egg_count:$('#ab_count').val(),start_date:$('#ab_start').val(),hatch_date:$('#ab_hatch').val(),notes:$('#ab_notes').val()},dataType:'json',
    success:r=>{hideLoader();if(r.success){showToast('Batch started!');setTimeout(()=>location.reload(),700);}else showToast(r.message,'error');},
    error:()=>{hideLoader();showToast('Server error.','error');}
  });
}
function editBatch(b){
  $('#eb_id').val(b.id);$('#eb_name').val(b.batch_name);$('#eb_type').val(b.egg_type);
  $('#eb_count').val(b.egg_count);$('#eb_hatch').val(b.expected_hatch_date);
  $('#eb_status').val(b.status);$('#eb_notes').val(b.notes||'');
  new bootstrap.Modal(document.getElementById('editBatchModal')).show();
}
function updateBatch(){
  showLoader('Updating Batch…');
  $.ajax({url:'../ajax/user_batches.php',method:'POST',data:{action:'update',id:$('#eb_id').val(),name:$('#eb_name').val(),egg_type:$('#eb_type').val(),egg_count:$('#eb_count').val(),hatch_date:$('#eb_hatch').val(),status:$('#eb_status').val(),notes:$('#eb_notes').val()},dataType:'json',
    success:r=>{hideLoader();if(r.success){showToast('Batch updated!');setTimeout(()=>location.reload(),700);}else showToast(r.message,'error');},
    error:()=>{hideLoader();showToast('Server error.','error');}
  });
}
function deleteBatch(id){
  showConfirm('Delete batch', 'Delete this batch?', function(){
    showLoader('Deleting…');
    $.post('../ajax/user_batches.php',{action:'delete',id},r=>{hideLoader();if(r.success){showToast('Deleted');setTimeout(()=>location.reload(),600);}else showToast(r.message,'error');},'json');
  });
}
</script>
<?php require_once 'footer.php'; ?>
