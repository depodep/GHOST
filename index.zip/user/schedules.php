<?php
$pageTitle = 'My Schedules';
$pageSubtitle = 'View and manage your incubation schedule';
$activePage = 'schedules';
require_once 'header.php';
$pdo = getDB();
$uid = $_SESSION['user_id'];
$schedules = $pdo->prepare("SELECT s.*, i.name as incubator_name, b.batch_name FROM schedules s JOIN incubators i ON s.incubator_id=i.id LEFT JOIN batches b ON s.batch_id=b.id WHERE b.user_id=? OR (s.created_by_role='user' AND s.created_by_id=?) ORDER BY s.scheduled_date DESC, s.scheduled_time DESC"); $schedules->execute([$uid,$uid]); $schedules = $schedules->fetchAll();
$incubators = $pdo->query("SELECT id,name FROM incubators WHERE status='active'")->fetchAll();
$batches_q = $pdo->prepare("SELECT id,batch_name,incubator_id FROM batches WHERE user_id=? AND status='incubating'"); $batches_q->execute([$uid]); $myBatches = $batches_q->fetchAll();
?>
<div class="d-flex justify-content-end mb-4">
  <button class="btn-ghost" data-bs-toggle="modal" data-bs-target="#addSchedModal"><i class="fas fa-plus me-2"></i>Add Schedule</button>
</div>
<div class="ghost-panel">
  <div class="ghost-panel-header"><span class="ghost-panel-title">📅 My Schedules</span></div>
  <div class="ghost-panel-body p-0">
    <table class="ghost-table">
      <thead><tr><th>Title</th><th>Incubator</th><th>Date & Time</th><th>Type</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach($schedules as $s): ?>
        <tr>
          <td><div style="font-weight:600;color:white;"><?= htmlspecialchars($s['title']) ?></div><?php if($s['batch_name']): ?><div style="font-size:.72rem;color:var(--ghost-muted);"><?= htmlspecialchars($s['batch_name']) ?></div><?php endif; ?></td>
          <td style="font-size:.85rem;"><?= htmlspecialchars($s['incubator_name']) ?></td>
          <td><div style="font-size:.85rem;font-weight:600;"><?= date('M j, Y',strtotime($s['scheduled_date'])) ?></div><div style="font-size:.72rem;color:var(--ghost-muted);"><?= substr($s['scheduled_time'],0,5) ?></div></td>
          <td style="font-size:.8rem;"><?= actionIcon($s['action_type'], true) ?></td>
          <td><span class="badge-<?= $s['status'] ?>"><?= $s['status'] ?></span></td>
          <td>
            <div class="d-flex gap-2">
              <?php if($s['status']=='pending'): ?><button class="btn-edit-ghost" style="font-size:.72rem;padding:5px 10px;" onclick="markDone(<?= $s['id'] ?>)">✓</button><?php endif; ?>
              <?php if($s['created_by_role']=='user'&&$s['created_by_id']==$uid): ?>
              <button class="btn-edit-ghost" onclick="editSched(<?= htmlspecialchars(json_encode($s)) ?>)"><i class="fas fa-pen"></i></button>
              <button class="btn-danger-ghost" onclick="deleteSched(<?= $s['id'] ?>)"><i class="fas fa-trash"></i></button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ADD SCHEDULE MODAL -->
<div class="modal fade modal-ghost" id="addSchedModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title"><i class="fas fa-calendar-plus me-2" style="color:var(--ghost-blue)"></i>Add Schedule</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" style="padding:24px;">
        <div class="row g-3">
          <div class="col-12"><label class="form-label-ghost">Title</label><input type="text" class="form-control-ghost" id="as_title" placeholder="e.g. Evening Turning"></div>
          <div class="col-md-6">
            <label class="form-label-ghost">Batch</label>
            <select class="form-select-ghost" id="as_batch">
              <option value="">General</option>
              <?php foreach($myBatches as $b): ?><option value="<?= $b['id'] ?>" data-inc="<?= $b['incubator_id'] ?>"><?= htmlspecialchars($b['batch_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label-ghost">Incubator</label>
            <select class="form-select-ghost" id="as_incubator">
              <?php foreach($incubators as $i): ?><option value="<?= $i['id'] ?>"><?= htmlspecialchars($i['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6"><label class="form-label-ghost">Date</label><input type="date" class="form-control-ghost" id="as_date" value="<?= date('Y-m-d') ?>"></div>
          <div class="col-md-6"><label class="form-label-ghost">Time</label><input type="time" class="form-control-ghost" id="as_time" value="<?= date('H:i') ?>"></div>
          <div class="col-12">
            <label class="form-label-ghost">Action Type</label>
            <select class="form-select-ghost" id="as_action">
              <option value="turning">🔄 Egg Turning</option><option value="temperature_check">🌡️ Temperature Check</option>
              <option value="humidity_check">💧 Humidity Check</option><option value="candling">🕯️ Candling</option><option value="hatch">🐣 Hatch Day</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer"><button class="btn-outline-ghost" data-bs-dismiss="modal">Cancel</button><button class="btn-ghost" onclick="addSched()"><i class="fas fa-save me-2"></i>Save</button></div>
    </div>
  </div>
</div>

<!-- EDIT MODAL -->
<div class="modal fade modal-ghost" id="editSchedModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Edit Schedule</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" style="padding:24px;">
        <input type="hidden" id="es2_id">
        <div class="row g-3">
          <div class="col-12"><label class="form-label-ghost">Title</label><input type="text" class="form-control-ghost" id="es2_title"></div>
          <div class="col-md-6"><label class="form-label-ghost">Date</label><input type="date" class="form-control-ghost" id="es2_date"></div>
          <div class="col-md-6"><label class="form-label-ghost">Time</label><input type="time" class="form-control-ghost" id="es2_time"></div>
          <div class="col-12"><label class="form-label-ghost">Action Type</label><select class="form-select-ghost" id="es2_action"><option value="turning">🔄 Egg Turning</option><option value="temperature_check">🌡️ Temperature Check</option><option value="humidity_check">💧 Humidity Check</option><option value="candling">🕯️ Candling</option><option value="hatch">🐣 Hatch Day</option></select></div>
        </div>
      </div>
      <div class="modal-footer"><button class="btn-outline-ghost" data-bs-dismiss="modal">Cancel</button><button class="btn-ghost" onclick="updateSched()"><i class="fas fa-save me-2"></i>Update</button></div>
    </div>
  </div>
</div>

<script>
function addSched(){
  showLoader('Saving Schedule…');
  $.ajax({url:'../ajax/user_schedules.php',method:'POST',data:{action:'add',title:$('#as_title').val(),batch_id:$('#as_batch').val(),incubator_id:$('#as_incubator').val(),date:$('#as_date').val(),time:$('#as_time').val(),action_type:$('#as_action').val()},dataType:'json',
    success:r=>{hideLoader();if(r.success){showToast('Schedule added!');setTimeout(()=>location.reload(),700);}else showToast(r.message,'error');},
    error:()=>{hideLoader();showToast('Server error.','error');}
  });
}
function editSched(s){
  $('#es2_id').val(s.id);$('#es2_title').val(s.title);$('#es2_date').val(s.scheduled_date);
  $('#es2_time').val(s.scheduled_time.substring(0,5));$('#es2_action').val(s.action_type);
  new bootstrap.Modal(document.getElementById('editSchedModal')).show();
}
function updateSched(){
  showLoader('Updating Schedule…');
  $.ajax({url:'../ajax/user_schedules.php',method:'POST',data:{action:'update',id:$('#es2_id').val(),title:$('#es2_title').val(),date:$('#es2_date').val(),time:$('#es2_time').val(),action_type:$('#es2_action').val()},dataType:'json',
    success:r=>{hideLoader();if(r.success){showToast('Updated!');setTimeout(()=>location.reload(),700);}else showToast(r.message,'error');},
    error:()=>{hideLoader();showToast('Server error.','error');}
  });
}
function deleteSched(id){
  showConfirm('Delete schedule', 'Delete this schedule?', function(){
    showLoader('Deleting…');
    $.post('../ajax/user_schedules.php',{action:'delete',id},r=>{hideLoader();if(r.success){showToast('Deleted');setTimeout(()=>location.reload(),600);}else showToast(r.message,'error');},'json');
  });
}
function markDone(id){
  showLoader('Marking Done…');
  $.post('../ajax/user_schedules.php',{action:'mark_done',id},r=>{hideLoader();if(r.success){showToast('Marked done!');setTimeout(()=>location.reload(),600);}else showToast(r.message,'error');},'json');
}
</script>
<?php require_once 'footer.php'; ?>
