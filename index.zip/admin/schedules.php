<?php
$pageTitle = 'Schedules';
$pageSubtitle = 'Manage incubation schedules';
$activePage = 'schedules';
require_once 'header.php';
$pdo = getDB();
$schedules = $pdo->query("SELECT s.*, i.name as incubator_name, b.batch_name FROM schedules s JOIN incubators i ON s.incubator_id=i.id LEFT JOIN batches b ON s.batch_id=b.id ORDER BY s.scheduled_date DESC, s.scheduled_time DESC")->fetchAll();
$incubators = $pdo->query("SELECT id, name FROM incubators WHERE status != 'maintenance'")->fetchAll();
$batches = $pdo->query("SELECT id, batch_name, incubator_id FROM batches WHERE status='incubating'")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
  <div class="d-flex gap-2">
    <button class="btn-outline-ghost btn-ghost-sm active-filter" data-filter="all" onclick="filterSchedules('all',this)">All</button>
    <button class="btn-outline-ghost btn-ghost-sm" data-filter="pending" onclick="filterSchedules('pending',this)">Pending</button>
    <button class="btn-outline-ghost btn-ghost-sm" data-filter="done" onclick="filterSchedules('done',this)">Done</button>
    <button class="btn-outline-ghost btn-ghost-sm" data-filter="missed" onclick="filterSchedules('missed',this)">Missed</button>
  </div>
  <button class="btn-ghost" data-bs-toggle="modal" data-bs-target="#addScheduleModal"><i class="fas fa-plus me-2"></i>Add Schedule</button>
</div>

<div class="ghost-panel">
  <div class="ghost-panel-header"><span class="ghost-panel-title">📅 All Schedules</span></div>
  <div class="ghost-panel-body p-0">
    <table class="ghost-table" id="scheduleTable">
      <thead><tr><th>Title</th><th>Incubator</th><th>Batch</th><th>Date & Time</th><th>Action</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach($schedules as $s): ?>
        <tr data-status="<?= $s['status'] ?>">
          <td><div style="font-weight:600;color:white;"><?= htmlspecialchars($s['title']) ?></div><div style="font-size:0.75rem;color:var(--ghost-muted);"><?= $s['description'] ? substr($s['description'],0,40).'...' : '' ?></div></td>
          <td style="font-size:0.85rem;"><?= htmlspecialchars($s['incubator_name']) ?></td>
          <td style="font-size:0.82rem;color:var(--ghost-muted);"><?= $s['batch_name'] ?? '—' ?></td>
          <td><div style="font-size:0.85rem;font-weight:600;"><?= date('M j, Y',strtotime($s['scheduled_date'])) ?></div><div style="font-size:0.75rem;color:var(--ghost-muted);"><?= substr($s['scheduled_time'],0,5) ?></div></td>
          <td><span style="font-size:0.8rem;"><?= actionIcon($s['action_type'], true) ?></span></td>
          <td><span class="badge-<?= $s['status'] ?>"><?= $s['status'] ?></span></td>
          <td>
            <div class="d-flex gap-2">
              <?php if($s['status']=='pending'): ?><button class="btn-edit-ghost" style="font-size:0.72rem;padding:5px 10px;" onclick="markDone(<?= $s['id'] ?>)">✓ Done</button><?php endif; ?>
              <button class="btn-edit-ghost" onclick="editSchedule(<?= htmlspecialchars(json_encode($s)) ?>)"><i class="fas fa-pen"></i></button>
              <button class="btn-danger-ghost" onclick="deleteSchedule(<?= $s['id'] ?>)"><i class="fas fa-trash"></i></button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ADD SCHEDULE MODAL -->
<div class="modal fade modal-ghost" id="addScheduleModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fas fa-calendar-plus me-2" style="color:var(--ghost-amber)"></i>Add New Schedule</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="padding:24px;">
        <div class="row g-3">
          <div class="col-12"><label class="form-label-ghost">Title</label><input type="text" class="form-control-ghost" id="s_title" placeholder="e.g. Morning Egg Turning"></div>
          <div class="col-md-6">
            <label class="form-label-ghost">Incubator</label>
            <select class="form-select-ghost" id="s_incubator" onchange="loadBatches(this.value)">
              <option value="">Select Incubator</option>
              <?php foreach($incubators as $i): ?><option value="<?= $i['id'] ?>"><?= htmlspecialchars($i['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label-ghost">Batch (optional)</label>
            <select class="form-select-ghost" id="s_batch"><option value="">All batches</option></select>
          </div>
          <div class="col-md-6"><label class="form-label-ghost">Date</label><input type="date" class="form-control-ghost" id="s_date" value="<?= date('Y-m-d') ?>"></div>
          <div class="col-md-6"><label class="form-label-ghost">Time</label><input type="time" class="form-control-ghost" id="s_time" value="<?= date('H:i') ?>"></div>
          <div class="col-md-6">
            <label class="form-label-ghost">Action Type</label>
            <select class="form-select-ghost" id="s_action">
              <option value="turning">🔄 Egg Turning</option>
              <option value="temperature_check">🌡️ Temperature Check</option>
              <option value="humidity_check">💧 Humidity Check</option>
              <option value="candling">🕯️ Candling</option>
              <option value="hatch">🐣 Hatch Day</option>
              <option value="maintenance">⚙️ Maintenance</option>
            </select>
          </div>
          <div class="col-md-3"><label class="form-label-ghost">Target Temp (°C)</label><input type="number" step="0.1" class="form-control-ghost" id="s_temp" placeholder="37.5"></div>
          <div class="col-md-3"><label class="form-label-ghost">Target Humidity (%)</label><input type="number" step="0.1" class="form-control-ghost" id="s_humidity" placeholder="55"></div>
          <div class="col-12"><label class="form-label-ghost">Notes</label><textarea class="form-control-ghost" id="s_notes" rows="2" placeholder="Optional notes..."></textarea></div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn-outline-ghost" data-bs-dismiss="modal">Cancel</button>
        <button class="btn-ghost" onclick="addSchedule()"><i class="fas fa-save me-2"></i>Save Schedule</button>
      </div>
    </div>
  </div>
</div>

<!-- EDIT SCHEDULE MODAL -->
<div class="modal fade modal-ghost" id="editScheduleModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fas fa-calendar-edit me-2" style="color:var(--ghost-blue)"></i>Edit Schedule</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="padding:24px;">
        <input type="hidden" id="es_id">
        <div class="row g-3">
          <div class="col-12"><label class="form-label-ghost">Title</label><input type="text" class="form-control-ghost" id="es_title"></div>
          <div class="col-md-6"><label class="form-label-ghost">Date</label><input type="date" class="form-control-ghost" id="es_date"></div>
          <div class="col-md-6"><label class="form-label-ghost">Time</label><input type="time" class="form-control-ghost" id="es_time"></div>
          <div class="col-md-6">
            <label class="form-label-ghost">Action Type</label>
            <select class="form-select-ghost" id="es_action">
              <option value="turning">🔄 Egg Turning</option>
              <option value="temperature_check">🌡️ Temperature Check</option>
              <option value="humidity_check">💧 Humidity Check</option>
              <option value="candling">🕯️ Candling</option>
              <option value="hatch">🐣 Hatch Day</option>
              <option value="maintenance">⚙️ Maintenance</option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label-ghost">Status</label>
            <select class="form-select-ghost" id="es_status">
              <option value="pending">Pending</option>
              <option value="done">Done</option>
              <option value="missed">Missed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
          <div class="col-12"><label class="form-label-ghost">Notes</label><textarea class="form-control-ghost" id="es_notes" rows="2"></textarea></div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn-outline-ghost" data-bs-dismiss="modal">Cancel</button>
        <button class="btn-ghost" onclick="updateSchedule()"><i class="fas fa-save me-2"></i>Update</button>
      </div>
    </div>
  </div>
</div>

<script>
const allBatches = <?= json_encode($batches) ?>;

function openAddSchedule(){ new bootstrap.Modal(document.getElementById('addScheduleModal')).show(); }

function loadBatches(incId){
  const sel = document.getElementById('s_batch');
  sel.innerHTML = '<option value="">All batches</option>';
  allBatches.filter(b=>b.incubator_id==incId).forEach(b=>{
    sel.innerHTML += `<option value="${b.id}">${b.batch_name}</option>`;
  });
}

function addSchedule(){
  showLoader('Saving Schedule…');
  $.ajax({
    url:'../ajax/admin_schedules.php',method:'POST',
    data:{action:'add',title:$('#s_title').val(),incubator_id:$('#s_incubator').val(),batch_id:$('#s_batch').val(),date:$('#s_date').val(),time:$('#s_time').val(),action_type:$('#s_action').val(),target_temp:$('#s_temp').val(),target_humidity:$('#s_humidity').val(),notes:$('#s_notes').val()},
    dataType:'json',
    success:r=>{hideLoader();if(r.success){showToast('Schedule added!');setTimeout(()=>location.reload(),700);}else showToast(r.message,'error');},
    error:()=>{hideLoader();showToast('Server error.','error');}
  });
}

function editSchedule(s){
  $('#es_id').val(s.id);$('#es_title').val(s.title);$('#es_date').val(s.scheduled_date);
  $('#es_time').val(s.scheduled_time.substring(0,5));$('#es_action').val(s.action_type);
  $('#es_status').val(s.status);$('#es_notes').val(s.description||'');
  new bootstrap.Modal(document.getElementById('editScheduleModal')).show();
}

function updateSchedule(){
  showLoader('Updating Schedule…');
  $.ajax({
    url:'../ajax/admin_schedules.php',method:'POST',
    data:{action:'update',id:$('#es_id').val(),title:$('#es_title').val(),date:$('#es_date').val(),time:$('#es_time').val(),action_type:$('#es_action').val(),status:$('#es_status').val(),notes:$('#es_notes').val()},
    dataType:'json',
    success:r=>{hideLoader();if(r.success){showToast('Schedule updated!');setTimeout(()=>location.reload(),700);}else showToast(r.message,'error');},
    error:()=>{hideLoader();showToast('Server error.','error');}
  });
}

function deleteSchedule(id){
  showConfirm('Delete schedule', 'Delete this schedule?', function(){
    showLoader('Deleting…');
    $.post('../ajax/admin_schedules.php',{action:'delete',id},r=>{
      hideLoader();if(r.success){showToast('Deleted!');setTimeout(()=>location.reload(),600);}    },'json');
  });
}

function markDone(id){
  showLoader('Marking Done…');
  $.post('../ajax/admin_schedules.php',{action:'mark_done',id},r=>{
    hideLoader();if(r.success){showToast('Marked as done!');setTimeout(()=>location.reload(),600);}
  },'json');
}

function filterSchedules(status, btn){
  document.querySelectorAll('[data-filter]').forEach(b=>b.style.borderColor='');
  if(btn) btn.style.borderColor='var(--ghost-amber)';
  $('#scheduleTable tbody tr').each(function(){
    $(this).toggle(status==='all' || $(this).data('status')===status);
  });
}
</script>
<?php require_once 'footer.php'; ?>
