<?php
require_once '../includes/config.php';
requireUser();
$pdo = getDB();
$uid = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

if($action === 'add'){
  $title = trim($_POST['title']??'');
  $incubator_id = (int)($_POST['incubator_id']??0);
  $batch_id = !empty($_POST['batch_id']) ? (int)$_POST['batch_id'] : null;
  $date = $_POST['date']??'';
  $time = $_POST['time']??'';
  $action_type = $_POST['action_type']??'turning';
  if(empty($title)||!$incubator_id||empty($date)||empty($time)){ jsonResponse(['success'=>false,'message'=>'Required fields missing']); }
  $stmt = $pdo->prepare("INSERT INTO schedules (incubator_id,batch_id,title,scheduled_date,scheduled_time,action_type,created_by_role,created_by_id) VALUES (?,?,?,?,?,?,'user',?)");
  $stmt->execute([$incubator_id,$batch_id,$title,$date,$time,$action_type,$uid]);
  jsonResponse(['success'=>true]);
}

if($action === 'update'){
  $id = (int)($_POST['id']??0);
  $stmt = $pdo->prepare("UPDATE schedules SET title=?,scheduled_date=?,scheduled_time=?,action_type=? WHERE id=? AND created_by_role='user' AND created_by_id=?");
  $stmt->execute([$_POST['title']??'',$_POST['date']??'',$_POST['time']??'',$_POST['action_type']??'turning',$id,$uid]);
  jsonResponse(['success'=>true]);
}

if($action === 'delete'){
  $id = (int)($_POST['id']??0);
  $pdo->prepare("DELETE FROM schedules WHERE id=? AND created_by_role='user' AND created_by_id=?")->execute([$id,$uid]);
  jsonResponse(['success'=>true]);
}

if($action === 'mark_done'){
  $id = (int)($_POST['id']??0);
  $pdo->prepare("UPDATE schedules SET status='done' WHERE id=?")->execute([$id]);
  jsonResponse(['success'=>true]);
}
?>
