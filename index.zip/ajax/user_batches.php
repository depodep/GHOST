<?php
require_once '../includes/config.php';
requireUser();
$pdo = getDB();
$uid = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

if($action === 'add'){
  $name = trim($_POST['name']??'');
  $incubator_id = (int)($_POST['incubator_id']??0);
  $egg_type = $_POST['egg_type']??'Chicken';
  $egg_count = (int)($_POST['egg_count']??0);
  $start_date = $_POST['start_date']??'';
  $hatch_date = $_POST['hatch_date']??'';
  $notes = trim($_POST['notes']??'');
  if(empty($name)||!$incubator_id||empty($start_date)||empty($hatch_date)){ jsonResponse(['success'=>false,'message'=>'Required fields missing']); }
  $stmt = $pdo->prepare("INSERT INTO batches (incubator_id,user_id,batch_name,egg_type,egg_count,start_date,expected_hatch_date,notes) VALUES (?,?,?,?,?,?,?,?)");
  $stmt->execute([$incubator_id,$uid,$name,$egg_type,$egg_count,$start_date,$hatch_date,$notes]);
  logActivity('user',$uid,'Add Batch',"Started: $name");
  jsonResponse(['success'=>true]);
}

if($action === 'update'){
  $id = (int)($_POST['id']??0);
  $stmt = $pdo->prepare("UPDATE batches SET batch_name=?,egg_type=?,egg_count=?,expected_hatch_date=?,status=?,notes=? WHERE id=? AND user_id=?");
  $stmt->execute([$_POST['name']??'',$_POST['egg_type']??'Chicken',(int)($_POST['egg_count']??0),$_POST['hatch_date']??'',$_POST['status']??'incubating',trim($_POST['notes']??''),$id,$uid]);
  jsonResponse(['success'=>true]);
}

if($action === 'delete'){
  $id = (int)($_POST['id']??0);
  $pdo->prepare("DELETE FROM batches WHERE id=? AND user_id=?")->execute([$id,$uid]);
  jsonResponse(['success'=>true]);
}
?>
